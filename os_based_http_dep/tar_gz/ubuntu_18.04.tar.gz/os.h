#pragma once

#define OS "ubuntu_18"
